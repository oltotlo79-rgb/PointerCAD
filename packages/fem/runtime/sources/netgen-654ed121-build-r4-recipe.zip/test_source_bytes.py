"""Root-only admission controls against the pinned original archive bytes."""

import copy
import hashlib
import json
from pathlib import Path
import runpy
import unittest

PACKET = Path(__file__).resolve().parent
AUDIT = runpy.run_path(str(PACKET / "audit.py"))
INPUTS = json.loads((PACKET / "inputs.json").read_text())
RAW_SHA = "cf4f7134c3d629094cea248b72e5fd87595a8af0bbc5120b674874afa9f13beb"
OLD_CAPTURE_SHA = "2b5cec5331e70788d8aa4b236550d3df1c7116a540438fd060acfee8e82d1606"


class SourceByteControls(unittest.TestCase):
    def test_pristine_archive_all_three_source_pins(self):
        value = AUDIT["native_link_archive_members"](INPUTS)
        self.assertEqual(set(value), {"ng/CMakeLists.txt", "nglib/CMakeLists.txt", "ng/netgenpy.cpp"})
        self.assertEqual(value["ng/netgenpy.cpp"], {
            "sha256": RAW_SHA, "bytes": 1075, "crlfCount": 30, "lfCount": 30,
        })

    def test_actual_old_text_capture_is_not_a_source_byte_pin(self):
        raw = (PACKET / "pristine-ng-netgenpy.cpp").read_bytes()
        capture = (PACKET / "netgen-netgenpy.cpp").read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(), RAW_SHA)
        self.assertEqual(hashlib.sha256(capture).hexdigest(), OLD_CAPTURE_SHA)
        self.assertNotEqual(raw, capture)
        self.assertEqual(raw.replace(b"\r\n", b"\n"), capture)
        wrong = copy.deepcopy(INPUTS)
        wrong["nativeLinkSourcePins"]["ng/netgenpy.cpp"] = OLD_CAPTURE_SHA
        with self.assertRaisesRegex(ValueError, "archive source-byte pin mismatch: ng/netgenpy.cpp"):
            AUDIT["native_link_archive_members"](wrong)

    def test_other_source_pin_drift_and_omission_refuse(self):
        for name in INPUTS["nativeLinkSourcePins"]:
            wrong = copy.deepcopy(INPUTS)
            wrong["nativeLinkSourcePins"][name] = "0" * 64
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, "source-byte pin mismatch"):
                AUDIT["native_link_archive_members"](wrong)
        missing = copy.deepcopy(INPUTS)
        del missing["nativeLinkSourcePins"]["ng/netgenpy.cpp"]
        with self.assertRaisesRegex(ValueError, "source coverage changed"):
            AUDIT["native_link_archive_members"](missing)


if __name__ == "__main__":
    unittest.main()
