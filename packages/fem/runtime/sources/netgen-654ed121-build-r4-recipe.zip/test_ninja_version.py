"""Root-only controls for the exact pinned binary's observed version banner."""
from pathlib import Path
import re
import subprocess
import unittest


class NinjaVersionControls(unittest.TestCase):
    def test_actual_banner_accepted_wrong_versions_refused(self):
        build = Path(__file__).with_name('build.sh').read_text()
        matches = re.findall(r"^grep -Fx '([^']+)' \"\$LOG/06-ninja.stdout\" >/dev/null$", build, re.MULTILINE)
        self.assertEqual(len(matches), 1)
        cases = [(b'1.13.2.git.kitware.jobserver-pipe-1\n', 0),
                 (b'1.13.2\n', 1), (b'1.13.1\n', 1),
                 (b'1.13.2.git.kitware.jobserver-pipe-2\n', 1)]
        for banner, expected in cases:
            with self.subTest(banner=banner):
                result = subprocess.run(['/usr/bin/grep', '-Fx', matches[0]], input=banner,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                        timeout=5, check=False)
                self.assertEqual(result.returncode, expected, result.stderr)

    def test_old_guard_rejects_observed_actual_banner(self):
        result = subprocess.run(['/usr/bin/grep', '-Fx', '1.13.2'],
                                input=b'1.13.2.git.kitware.jobserver-pipe-1\n',
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=5, check=False)
        self.assertEqual(result.returncode, 1)


if __name__ == '__main__':
    unittest.main()
