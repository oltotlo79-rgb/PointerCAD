"""Root-only independent saved-failure and provider-integrity controls."""

import hashlib
from pathlib import Path
import runpy
import unittest

PACKET = Path(__file__).resolve().parent
LINKAGE = runpy.run_path(str(PACKET / "target_linkage.py"))
TASK = Path("/home/yuya/pcad-netgen-clean-20261012-build-r2")
ZLIB = str(TASK / "target/lib/libz.a")
SAVED = (PACKET / "actual-link-stanzas.txt").read_bytes()
if hashlib.sha256(SAVED).hexdigest() != "ba8aa2c79cd8e374199b3f7f74552077106988926e3bbdca0df9d2cb0e7b7fa6":
    raise ValueError("actual failed link graph fixture changed")
OLD = SAVED.decode("utf-8")
# Keep the actual nglib stanza byte-for-byte. The prospective ngpy graph removes
# the archive from its implicit dependency and LINK_LIBRARIES; it adds no flags.
PREFIX, NGPY = OLD.split("build ng/libngpy.so:", 1)
NEW = PREFIX + "build ng/libngpy.so:" + NGPY.replace(ZLIB + " ", "")


class TargetLinkageControls(unittest.TestCase):
    def test_saved_actual_failed_graph_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "second static zlib"):
            LINKAGE["check_link_graph"](OLD, TASK)

    def test_single_owner_graph_retains_exact_provider(self):
        value = LINKAGE["check_link_graph"](NEW, TASK)
        self.assertEqual(value["zlibOwner"], "libnglib.so")
        self.assertEqual(value["nglib"], [ZLIB, "libsrc/core/libngcore.so", "-ldl"])
        self.assertEqual(value["ngpy"], ["libnglib.so", "libsrc/core/libngcore.so", "-ldl"])

    def test_missing_and_foreign_providers_are_rejected(self):
        for value in (NEW.replace(ZLIB, ""), NEW.replace(ZLIB, "/usr/lib/libz.a"),
                      NEW.replace(ZLIB, "-lz"), NEW.replace(ZLIB, ZLIB + " " + ZLIB),
                      NEW.replace("LINK_LIBRARIES = libnglib.so", "LINK_LIBRARIES =")):
            with self.subTest(value=value[-300:]), self.assertRaises(ValueError):
                LINKAGE["check_link_graph"](value, TASK)

    def test_duplicate_target_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "ambiguous"):
            LINKAGE["check_link_graph"](NEW + NEW, TASK)

    def test_exact_source_patch_preserves_other_platform_and_provider(self):
        source = (PACKET / "upstream-ng-CMakeLists.txt").read_bytes()
        result = LINKAGE["patched_source"](source).decode()
        self.assertIn("if(NOT EMSCRIPTEN)\n        target_link_libraries(ngpy PRIVATE ${ZLIB_LIBRARIES})", result)
        self.assertIn('target_link_libraries( ngpy PUBLIC nglib PRIVATE "$<BUILD_INTERFACE:netgen_python>" )', result)
        nglib = (PACKET / "netgen-nglib-CMakeLists.txt").read_bytes()
        self.assertEqual(hashlib.sha256(nglib).hexdigest(),
                         "36ee6c0a1794cb1042c6e64745eb32614b7efc76a8a710cb7b7493852f53561e")
        self.assertIn(b"target_link_libraries(nglib PRIVATE ${ZLIB_LIBRARIES})", nglib)

    def test_changed_or_already_patched_source_refuses(self):
        source = (PACKET / "upstream-ng-CMakeLists.txt").read_bytes()
        for value in (source + b"\n", LINKAGE["patched_source"](source)):
            with self.assertRaisesRegex(ValueError, "exact admitted upstream"):
                LINKAGE["patched_source"](value)


if __name__ == "__main__":
    unittest.main()
