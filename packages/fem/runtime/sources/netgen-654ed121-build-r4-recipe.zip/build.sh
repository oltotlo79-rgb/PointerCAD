#!/usr/bin/env bash
# Root-only. Derived from the successful reviewed OOFEM build lifecycle.
# Root runs canonical guard first, pins this script/packet and owns setsid/reaping.
# Never installs into the existing venv or writes product/runtime/old source files.
set -Eeuo pipefail
umask 022
[[ $# == 1 && $1 =~ ^[0-9a-f]{64}$ ]] || { echo 'requires exact packet manifest SHA256' >&2; exit 64; }
REPO=/mnt/c/Users/oltot/Documents/git-projects/PointerCAD
PACKET="$REPO/scratchpad/claude/agents/cx_v103_fem_runtime_astra/before/beam-buckling-result-order-r1/continuum-capability-r1/netgen-closure-r1/build-r4"
PRIOR=/home/yuya/pcad-oofem-rebuild-20261011-2136
TASK=/home/yuya/pcad-netgen-clean-20261012-build-r4
PY="$PRIOR/venv/bin/python"
echo "$1  $PACKET/manifest.json" | sha256sum -c -
echo "b3f693a8de6fe90bee7922ef4ee0c66bc8aafa637f5da1d461c09d557b2a1f60  $PY" | sha256sum -c -
# Bootstrap only standard-library byte checks, before importing this packet helper.
"$PY" -I -B - "$PACKET" <<'PY'
import hashlib, json, pathlib, sys
p = pathlib.Path(sys.argv[1])
m = json.loads((p / 'manifest.json').read_text())
for row in m['files']:
    target = p / row['path']
    if not target.resolve().is_relative_to(p.resolve()):
        raise SystemExit('packet path escape')
    if hashlib.sha256(target.read_bytes()).hexdigest() != row['sha256']:
        raise SystemExit('packet pin mismatch: ' + row['path'])
PY
[[ "$(ps -o pgid= -p $$ | tr -d ' ')" == "$$" ]] || { echo 'own setsid process group required' >&2; exit 64; }
[[ ! -e "$TASK" && ! -L "$TASK" && "$(realpath -m "$TASK")" == "$TASK" ]] || exit 64
mkdir "$TASK"
mkdir "$TASK/logs" "$TASK/cache" "$TASK/tmp"
LOG="$TASK/logs"
CURRENT=bootstrap
on_signal() {
  trap '' INT TERM
  printf '%s INTERRUPTED %s during %s\n' "$(date --iso-8601=seconds)" "$1" "$CURRENT" >> "$LOG/steps.txt"
  kill -TERM -- "-$$"
  if [[ $1 == INT ]]; then exit 130; fi
  exit 143
}
finish() {
  local primary=$?
  trap - EXIT
  set +e
  "$PY" -I -B "$PACKET/audit.py" preserve "$TASK" "$PACKET" > "$LOG/preservation.stdout" 2> "$LOG/preservation.stderr"
  local preservation=$?
  printf '%s\n' "$primary" > "$LOG/primary.exit"
  printf '%s\n' "$preservation" > "$LOG/preservation.exit"
  printf '%s FINISHED primary=%s preservation=%s stage=%s\n' "$(date --iso-8601=seconds)" "$primary" "$preservation" "$CURRENT" >> "$LOG/steps.txt"
  if [[ $primary != 0 ]]; then exit "$primary"; fi
  exit "$preservation"
}
trap finish EXIT
trap 'on_signal INT' INT
trap 'on_signal TERM' TERM
step() {
  local name=$1; shift
  CURRENT=$name
  printf '%s %s\n' "$(date --iso-8601=seconds)" "$name" >> "$LOG/steps.txt"
  set +e
  "$@" > "$LOG/$name.stdout" 2> "$LOG/$name.stderr" &
  local pid=$!
  wait "$pid"
  local rc=$?
  set -e
  echo "$rc" > "$LOG/$name.exit"
  if [[ $rc != 0 ]]; then echo "FAILED $name exit $rc" >&2; exit "$rc"; fi
}
export PYTHONDONTWRITEBYTECODE=1 PIP_NO_INDEX=1 PIP_DISABLE_PIP_VERSION_CHECK=1
export PIP_CACHE_DIR="$TASK/cache/pip" XDG_CACHE_HOME="$TASK/cache"
export TMPDIR="$TASK/tmp" TEMP="$TASK/tmp" TMP="$TASK/tmp"
export CMAKE_BUILD_PARALLEL_LEVEL=4 PYODIDE_JOBS=4
unset CMAKE_ARGS SKBUILD_CMAKE_ARGS CFLAGS CXXFLAGS LDFLAGS CC CXX AR RANLIB
unset CMAKE_TOOLCHAIN_FILE PYTHONPATH PYTHONHOME PYODIDE_ROOT NETGEN_ARCH NETGEN_MPI
step 01-refusal-controls "$PY" -I -B "$PACKET/audit.py" controls
step 01-linkage-controls "$PY" -I -B "$PACKET/test_target_linkage.py"
step 01-source-byte-controls "$PY" -I -B "$PACKET/test_source_bytes.py"
step 02-admission "$PY" -I -B "$PACKET/audit.py" prepare "$TASK" "$PACKET"
# The exact existing env script is admitted before sourcing it.
source "$(cat "$PRIOR/emsdk_env_path")" > "$LOG/03-env.stdout" 2> "$LOG/03-env.stderr"
export EM_CACHE="$TASK/cache/emscripten" EM_FROZEN_CACHE=1
# Installed tools/config.py accepts this override. Missing target cache entries
# are a recorded failure, never a download or automatic system-library rebuild.
# Exact retained build-tool paths are supplied by admission; no pip fallback.
source "$TASK/build-tools.env"
export PATH="$NETGEN_BUILD_TOOLS_BIN:$PATH"
step 04-toolchain emcc --version
step 05-cmake "$NETGEN_CMAKE" --version
step 06-ninja "$NETGEN_NINJA" --version
grep -F '4.0.9' "$LOG/04-toolchain.stdout" >/dev/null
grep -Fx 'cmake version 4.4.4' "$LOG/05-cmake.stdout" >/dev/null
grep -Fx '1.13.2.git.kitware.jobserver-pipe-1' "$LOG/06-ninja.stdout" >/dev/null
mkdir "$TASK/target/lib" "$TASK/target/include"
cp "$TASK/src/zlib/zlib.h" "$TASK/src/zlib/zconf.h" "$TASK/target/include/"
zsrc=(adler32 compress crc32 deflate gzclose gzlib gzread gzwrite infback inffast inflate inftrees trees uncompr zutil)
objects=()
for name in "${zsrc[@]}"; do
  step "10-zlib-$name" emcc -O2 -fPIC -Wno-deprecated-non-prototype -I "$TASK/src/zlib" -c "$TASK/src/zlib/$name.c" -o "$TASK/objects/$name.o"
  objects+=("$TASK/objects/$name.o")
done
step 11-zlib-archive emar rcs "$TASK/target/lib/libz.a" "${objects[@]}"
step 12-zlib-audit "$PY" -I -B "$PACKET/audit.py" objects "$TASK" "$PACKET"
mapfile -t cmake_args < "$TASK/cmake-args.txt"
cd "$TASK/src/netgen"
step 20-build nice -n 10 "$PRIOR/venv/bin/pyodide" build . --no-isolation \
  --xbuildenv-path "$PRIOR/xbuildenv" --outdir "$TASK/dist" \
  --config-setting "build-dir=$TASK/skbuild" "${cmake_args[@]}"
step 21-result "$PY" -I -B "$PACKET/audit.py" result "$TASK" "$PACKET"
CURRENT=done
echo "BUILD COMPLETE $(date --iso-8601=seconds); native runtime proof still unexecuted" > "$LOG/done.txt"
