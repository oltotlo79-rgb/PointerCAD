"""Exact-source, Root-only correction of this Netgen target ownership graph."""

import hashlib
from pathlib import Path
import re


UPSTREAM_NG_SHA256 = "e7512177cceee339ec926c77f1d4977412e840854ab8f87c52a018ea4451b024"
OLD_LINK = (
    "    target_link_libraries( ngpy PRIVATE ${CMAKE_THREAD_LIBS_INIT} "
    "${JPEG_LIBRARIES} ${MKL_LIBRARIES} ${ZLIB_LIBRARIES} occ_libs netgen_cgns )\n"
)
NEW_LINK = (
    "    target_link_libraries( ngpy PRIVATE ${CMAKE_THREAD_LIBS_INIT} "
    "${JPEG_LIBRARIES} ${MKL_LIBRARIES} occ_libs netgen_cgns )\n"
    "    # The Emscripten side module imports zlib through its nglib owner.\n"
    "    # Do not enumerate an unused second static archive as ngpy exports.\n"
    "    if(NOT EMSCRIPTEN)\n"
    "        target_link_libraries(ngpy PRIVATE ${ZLIB_LIBRARIES})\n"
    "    endif()\n"
)


def patched_source(original):
    if hashlib.sha256(original).hexdigest() != UPSTREAM_NG_SHA256:
        raise ValueError("ng/CMakeLists.txt is not the exact admitted upstream source")
    text = original.decode("utf-8")
    if text.count(OLD_LINK) != 1:
        raise ValueError("ngpy original link declaration multiplicity changed")
    return text.replace(OLD_LINK, NEW_LINK, 1).encode("utf-8")


def link_libraries(ninja, target):
    blocks = re.findall(
        r"^build " + re.escape(target) + r":[^\n]*\n((?:[ \t]+[^\n]*\n)*)",
        ninja,
        flags=re.MULTILINE,
    )
    if len(blocks) != 1:
        raise ValueError("missing or ambiguous native link target: " + target)
    lines = [line.strip()[len("LINK_LIBRARIES = "):]
             for line in blocks[0].splitlines()
             if line.strip().startswith("LINK_LIBRARIES = ")]
    if len(lines) != 1:
        raise ValueError("missing or ambiguous LINK_LIBRARIES: " + target)
    return lines[0].split()


def check_link_graph(ninja, task):
    """Reject duplicate ngpy ownership in the effective generated link inputs."""
    expected_zlib = str(Path(task) / "target/lib/libz.a")
    ngpy = link_libraries(ninja, "ng/libngpy.so")
    nglib = link_libraries(ninja, "libnglib.so")
    if any("libz.a" in item or item == "-lz" for item in ngpy):
        raise ValueError("ngpy must not enumerate a second static zlib archive")
    if ngpy.count("libnglib.so") != 1:
        raise ValueError("ngpy lost its actual nglib provider")
    if nglib.count(expected_zlib) != 1:
        raise ValueError("nglib must retain exactly one isolated target zlib archive")
    if any(("libz.a" in item and item != expected_zlib) or item == "-lz"
           for item in nglib):
        raise ValueError("nglib has an unadmitted zlib provider")
    return {"ngpy": ngpy, "nglib": nglib, "zlibOwner": "libnglib.so"}
