__version__ = "6.2.2606.post5.dev0"
__package_name__ = "netgen-mesher"
