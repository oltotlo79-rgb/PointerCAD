/**
 * 式パーサーと任意精度評価(要件 FR-2xx)。
 * このパッケージは他の @pointercad/* に依存しない純粋ロジックとする。
 *
 * 評価と参照位置の読み取りは安全な公開関数を通す。tokenize / parse /
 * evaluateNode や内部ASTは輸出せず、内部の作りを後から変えられる余地を残す
 * (計画書 docs/plans/P1-式とスケッチ.md タスク7 手順2)。
 */

/**
 * このパッケージが受け付ける式の記法バージョン。保存した式を読み戻すときの互換判定に使う。
 * 1 → 2(2026-09-04、P4b タスク1): 変数名にひらがな・カタカナ・CJK統合漢字を許すよう
 * `tokenize.ts` の識別子の文字集合を広げた(FR-207)。版1で書かれた式(ASCIIの名前・π・
 * 関数呼び出し)はすべて版2でも同じように読めるので、読み手の後方互換は保たれる。
 *
 * 2 のまま据え置く(2026-09-06、P6 タスク1b、統括の判断): 長さの単位つきの数
 * (`1.5in` / `3/8"` / `(10*2)in`。FR-814)を足したが、**この値はどこからも参照されて
 * いない**(全リポジトリの Grep で、この宣言・`version.test.ts`・生成物の `dist` 以外に
 * 出現しない。`.pcad` の互換判定は `packages/io` のスキーマ版が担っており、この値は使って
 * いない)。版を上げても読み書きの振る舞いは 1 つも変わらず、P0〜P5 に保存された式は
 * すべてこれまでの文法で書かれていて新しい構文を含まないため、上げる実益が無い。
 */
export const EXPRESSION_SYNTAX_VERSION = 2;

/** 角度の単位。度を既定とする(FR-205)。 */
export type AngleUnit = 'degree' | 'radian';

export const DEFAULT_ANGLE_UNIT: AngleUnit = 'degree';

export { collectMathCoefficients } from './math/mathExpressionReferences.js';
export { inspectMathScalarExpression, mathScalarExpression, type MathScalarIssue } from './math/mathScalarExpression.js';
export { originalCoefficientExpression, exactCoefficientScalar, type MathCoefficientValue } from './math/mathCoefficientExpression.js';
export { decodeMathExpressionStorage } from './math/mathExpressionStorage.js';
export { bindMathCompositionNames, type MathCompositionCoefficient } from './math/mathComposition.js';
export type { StoredMathExpression } from './math/mathInputContract.js';
export { translateFunctionExpression, type FunctionAxisTranslation } from './math/translateFunctionExpression.js';

export {
  addExpression,
  composeExpressionSource,
  divideExpression,
  multiplyExpression,
  subtractExpression,
} from './combineExpression.js';
export type { ExpressionError, ExpressionErrorCode } from './errors.js';
export { EXPRESSION_MAX_EXPONENT, EXPRESSION_MAX_LENGTH } from './errors.js';
export {
  evaluateExpressionExact,
  EXPRESSION_PRECISION,
  FUNCTION_ARITY,
  type ExactEvaluateOptions,
  type ExactExpressionResult,
  type ExactExpressionValue,
} from './evaluate.js';
export { CONSTANT_TOKEN_NAMES } from './parse.js';
export {
  DISPLAY_SIGNIFICANT_DIGITS,
  evaluateExpression,
  exactExpressionValueFromNumber,
  expressionValueFromNumber,
  type EvaluateOptions,
  type ExpressionResult,
  type ExpressionValue,
} from './evaluateExpression.js';
export {
  LENGTH_UNITS,
  MM_PER_INCH_TEXT,
  toLengthUnit,
  type ExpressionLengthUnit,
} from './lengthUnits.js';
export { containsLengthUnit, normalizeExpressionSource } from './tokenize.js';
export {
  inspectExpression,
  type ExpressionInspection,
  type ExpressionReference,
  type ExpressionUnitReference,
} from './inspectExpression.js';
export {
  checkVariableName,
  collectVariableNames,
  isNumericLiteral,
  renameVariable,
  type VariableNameIssue,
} from './variableNames.js';
