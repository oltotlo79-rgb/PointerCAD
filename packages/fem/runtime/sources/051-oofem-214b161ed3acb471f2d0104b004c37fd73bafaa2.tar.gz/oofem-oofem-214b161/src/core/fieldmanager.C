/*
 *
 *                 #####    #####   ######  ######  ###   ###
 *               ##   ##  ##   ##  ##      ##      ## ### ##
 *              ##   ##  ##   ##  ####    ####    ##  #  ##
 *             ##   ##  ##   ##  ##      ##      ##     ##
 *            ##   ##  ##   ##  ##      ##      ##     ##
 *            #####    #####   ##      ######  ##     ##
 *
 *
 *             OOFEM : Object Oriented Finite Element Code
 *
 *               Copyright (C) 1993 - 2025   Borek Patzak
 *
 *
 *
 *       Czech Technical University, Faculty of Civil Engineering,
 *   Department of Structural Mechanics, 166 29 Prague, Czech Republic
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include "fieldmanager.h"
#include "datareader.h"
#include "inputrecord.h"
#include "classfactory.h"

namespace oofem {
FieldManager :: ~FieldManager()
{ }

void
FieldManager :: registerField(std :: shared_ptr< Field >eField, FieldType key)
{
  if (this->externalFields.find(key) == this->externalFields.end()) {
    this->externalFields.insert({key, eField});
  } else {
    this->externalFields.at(key)=eField;
  }
  /// could be replaced in future by 
  /// this->externalFields.insert_or_assign({key, eField});
}




bool
FieldManager :: isFieldRegistered(FieldType key)
{
    return ( this->externalFields.find(key) != this->externalFields.end() );
}

std :: shared_ptr< Field >
FieldManager :: giveField(FieldType key)
{
    auto i = this->externalFields.find(key);
    if ( i == this->externalFields.end() ) {
        std :: shared_ptr< Field >p; // std::shared_ptr<Field> p(nullptr);
        return p;
    }

    return i->second;
}

void
FieldManager :: unregisterField(FieldType key)
{
    auto i = this->externalFields.find(key);
    if ( i == this->externalFields.end() ) {
        return;
    }

    this->externalFields.erase(i);
}

std::vector<FieldType>
FieldManager :: giveRegisteredKeys()
{
    std::vector<FieldType> ret;
    for(const auto& keyField: this->externalFields) ret.push_back(keyField.first);
    return ret;
}



int FieldManager::instanciateYourself(DataReader &dr, InputRecord &ir)
{
  for(auto& fieldRecord: dr.giveGroupRecords(ir.ptr(),"nfields","Fields",DataReader::IR_fieldRec,/*optional*/true)){
    std :: string fname;
    fieldRecord.giveRecordKeywordField(fname);
    std :: shared_ptr< Field > fieldPtr = classFactory.createField(fname.c_str());
    if ( !fieldPtr ) {
      OOFEM_ERROR("unknown field name (%s)", fname.c_str());
    }
    fieldPtr->initializeFrom(fieldRecord);
    registerField(fieldPtr, fieldPtr->giveType());
  }
  return 1;
}

} // end namespace oofem
