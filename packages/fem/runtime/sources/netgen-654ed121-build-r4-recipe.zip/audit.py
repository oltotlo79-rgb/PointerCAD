"""Root-only data admission/extraction/audit for this one clean Netgen build.

No package imports, network, native loads, subprocesses or installation.
"""
import ast
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import runpy
import shutil
import stat
import sys
import tarfile
import tomllib
import zipfile

NETGEN = "654ed121e44cedc4db45f955d9ab6ddf8dd48806"
PYBIND = "98e50b702d9ab784ec918399aaa20adcfd1af9a9"
VERSION = "v6.2.2606-5-g654ed121"
LIBRARIES = {"libngcore.so", "libnglib.so"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def pinned(path, digest):
    require(isinstance(digest, str) and len(digest) == 64, "missing pin")
    require(sha(path) == digest, "pin mismatch: " + str(path))


def source_version(value):
    require(value == VERSION, "dirty or wrong Netgen source version")


def needed_libraries(names):
    require(set(names) <= LIBRARIES, "unknown required dynamic library")


def wasm(data):
    require(data[:8] == b"\x00asm\x01\x00\x00\x00", "not a WebAssembly object/module")


def safe_extract(archive, target, top):
    require(not target.exists(), "source target already exists")
    with tarfile.open(archive, "r:gz") as source:
        members = source.getmembers()
        names = set()
        for member in members:
            p = PurePosixPath(member.name)
            require(not p.is_absolute() and ".." not in p.parts and "\\" not in member.name,
                    "unsafe archive path")
            require(p.parts and p.parts[0] == top, "wrong archive root")
            require(member.isdir() or member.isfile(), "archive link/device refused")
            require(member.name not in names, "duplicate archive member")
            names.add(member.name)
        target.mkdir()
        for member in members:
            parts = PurePosixPath(member.name).parts[1:]
            if not parts:
                continue
            dest = target.joinpath(*parts)
            require(dest.resolve().is_relative_to(target.resolve()), "extraction escape")
            if member.isdir():
                dest.mkdir(parents=True, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with source.extractfile(member) as src, dest.open("xb") as dst:
                    shutil.copyfileobj(src, dst)


def tree_files(root):
    result = {}
    for current, directories, files in os.walk(root, followlinks=False):
        for name in directories + files:
            p = Path(current) / name
            require(not p.is_symlink(), "unexpected link in owned source/output: " + str(p))
        for name in files:
            p = Path(current) / name
            result[p.relative_to(root).as_posix()] = sha(p)
    return result


def extract_tool(wheel, target, binary):
    target.mkdir()
    with zipfile.ZipFile(wheel) as z:
        require(len(z.namelist()) == len(set(z.namelist())), "duplicate tool wheel member")
        for item in z.infolist():
            p = PurePosixPath(item.filename)
            require(not p.is_absolute() and ".." not in p.parts and "\\" not in item.filename,
                    "tool wheel path escape")
            mode = item.external_attr >> 16
            require(not stat.S_ISLNK(mode), "tool wheel symlink refused")
            dest = target.joinpath(*p.parts)
            require(dest.resolve().is_relative_to(target.resolve()), "tool extraction escape")
            if item.is_dir():
                dest.mkdir(parents=True, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with z.open(item) as src, dest.open("xb") as dst:
                    shutil.copyfileobj(src, dst)
        tool = target / binary
        data = tool.read_bytes()
        require(data[:6] == b"\x7fELF\x02\x01" and data[18:20] == b"\xb7\x00",
                "host build tool must match observed Linux aarch64")
        tool.chmod(0o755)
    return tool


def native_link_archive_members(inputs):
    """Validate source-byte pins against the actual archive, never captured text."""
    archive = inputs["netgenArchive"]
    rows = [row for row in inputs["files"] if row["path"] == archive]
    require(len(rows) == 1, "missing or ambiguous source archive pin")
    pinned(archive, rows[0]["sha256"])
    expected = inputs["nativeLinkSourcePins"]
    require(set(expected) == {"ng/CMakeLists.txt", "nglib/CMakeLists.txt", "ng/netgenpy.cpp"},
            "native link source coverage changed")
    result = {}
    with tarfile.open(archive, "r:gz") as source:
        members = source.getmembers()
        for name, digest in expected.items():
            path = "netgen-" + NETGEN + "/" + name
            matches = [member for member in members if member.name == path]
            require(len(matches) == 1 and matches[0].isfile(), "invalid source member: " + name)
            with source.extractfile(matches[0]) as stream:
                data = stream.read()
            actual = hashlib.sha256(data).hexdigest()
            require(actual == digest, "archive source-byte pin mismatch: " + name)
            result[name] = {"sha256": actual, "bytes": len(data),
                            "crlfCount": data.count(b"\r\n"), "lfCount": data.count(b"\n")}
    return result


def prepare(task, packet):
    inputs = json.loads((packet / "inputs.json").read_text())
    pinned(inputs["pywasmcrossPath"], inputs["pywasmcrossSha256"])
    for row in inputs["files"]:
        pinned(row["path"], row["sha256"])
    for row in inputs["environmentFiles"]:
        p = Path(row["path"])
        require(str(p.resolve()) == row["resolved"], "toolchain resolved path changed")
        pinned(p, row["sha256"])
    source_version(inputs["sourceVersion"])
    require(inputs["netgenCommit"] == NETGEN and inputs["pybindCommit"] == PYBIND,
            "source/gitlink mismatch")
    link_source_evidence = native_link_archive_members(inputs)
    for name in ("src", "objects", "target", "dist", "dist-source"):
        (task / name).mkdir()
    write(task / "dist-source/native-link-archive-members.json", link_source_evidence)
    safe_extract(inputs["netgenArchive"], task / "src/netgen", "netgen-" + NETGEN)
    empty = task / "src/netgen/external_dependencies/pybind11"
    if empty.exists():
        empty.rmdir()  # only an empty gitlink placeholder; no recursive deletion
    safe_extract(inputs["pybindArchive"], empty, "pybind11-" + PYBIND)
    safe_extract(inputs["zlibArchive"], task / "src/zlib", "zlib-1.3.1")
    source = task / "src/netgen"
    pinned(source / "pyproject.toml", inputs["upstreamPyprojectSha256"])
    pinned(packet / "pyproject.toml", inputs["patchedPyprojectSha256"])
    shutil.copyfile(source / "pyproject.toml", task / "dist-source/upstream-pyproject.toml")
    shutil.copyfile(packet / "pyproject.toml", source / "pyproject.toml")
    # Preserve the exact upstream target and apply only the admitted ownership fix.
    for name, digest in inputs["nativeLinkSourcePins"].items():
        pinned(source / name, digest)
    linkage = runpy.run_path(str(packet / "target_linkage.py"))
    original_link_source = (source / "ng/CMakeLists.txt").read_bytes()
    patched_link_source = linkage["patched_source"](original_link_source)
    shutil.copyfile(source / "ng/CMakeLists.txt", task / "dist-source/upstream-ng-CMakeLists.txt")
    (source / "ng/CMakeLists.txt").write_bytes(patched_link_source)
    write(task / "dist-source/native-link-patch.json", {
        "path": "ng/CMakeLists.txt",
        "beforeSha256": hashlib.sha256(original_link_source).hexdigest(),
        "afterSha256": hashlib.sha256(patched_link_source).hexdigest(),
        "change": "Emscripten ngpy imports nglib; only nglib owns target static zlib",
        "otherSourcePins": inputs["nativeLinkSourcePins"],
    })
    project = tomllib.loads((source / "pyproject.toml").read_text())
    require(project["build-system"]["requires"] == ["scikit-build-core==0.11.6"], "unexpected build dependency")
    require(project["project"]["dependencies"] == ["numpy"], "unexpected runtime dependency")
    require(project["project"]["version"] == "6.2.2606.post5.dev0", "wrong package version")
    defaults = project["tool"]["scikit-build"]["cmake"]["define"]
    for name in ("USE_SUPERBUILD", "USE_OCC", "USE_GUI", "BUILD_STUB_FILES", "BUILD_ZLIB"):
        require(defaults[name] == "OFF" and inputs["cmakeDefinitions"][name] == "OFF",
                "unsafe default or missing override: " + name)
    shutil.copyfile(task / "src/zlib/zconf.h", task / "dist-source/upstream-zconf.h")
    pinned(inputs["targetZconf"], inputs["targetZconfSha256"])
    shutil.copyfile(inputs["targetZconf"], task / "src/zlib/zconf.h")
    cache = Path(inputs["emscriptenCache"])
    require(cache.is_dir() and not cache.is_symlink(), "missing or linked prior SDK cache")
    cache_files = tree_files(cache)
    require(cache_files and any(name.startswith("sysroot/") for name in cache_files),
            "empty or missing SDK sysroot cache; no download permitted")
    write(task / "dist-source/prior-cache.json", cache_files)
    shutil.copytree(cache, task / "cache/emscripten", symlinks=False)
    (task / "tools").mkdir()
    tools = {}
    for row in inputs["toolWheels"]:
        pinned(row["path"], row["sha256"])
        tool = extract_tool(row["path"], task / "tools" / row["name"], row["binary"])
        pinned(tool, row["binarySha256"])
        tools[row["name"]] = tool
    with (task / "build-tools.env").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write("NETGEN_CMAKE='" + str(tools["cmake"]) + "'\n")
        stream.write("NETGEN_NINJA='" + str(tools["ninja"]) + "'\n")
        stream.write("NETGEN_BUILD_TOOLS_BIN='" + str(tools["cmake"].parent) + ":"
                     + str(tools["ninja"].parent) + "'\n")
    args = []
    for name, value in inputs["cmakeDefinitions"].items():
        require(name.replace("_", "").isalnum(), "invalid CMake key")
        require("\n" not in value and "\r" not in value, "invalid CMake value")
        args.extend(["--config-setting", "cmake.define." + name + "=" + value.replace("@TASK@", str(task))])
    with (task / "cmake-args.txt").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write("\n".join(args) + "\n")
    # Retain the complete exact source snapshots and actual modifications.
    write(task / "dist-source/source-before-build.json", tree_files(task / "src"))
    write(task / "dist-source/input-pins.json", inputs)
    write(task / "dist-source/tools.json", inputs["toolWheels"])
    print(json.dumps({"admitted": True, "sourceVersion": VERSION, "sources": 3}))


def object_audit(task):
    objects = sorted((task / "objects").glob("*.o"))
    require(len(objects) == 15, "zlib object count differs from installed port")
    for p in objects:
        wasm(p.read_bytes())
    require((task / "target/lib/libz.a").read_bytes()[:8] == b"!<arch>\n", "not static archive")
    write(task / "dist-source/zlib-target.json", {
        "objects": {p.name: sha(p) for p in objects},
        "librarySha256": sha(task / "target/lib/libz.a"),
        "headers": tree_files(task / "target/include"),
    })


def uleb(data, pos):
    value, shift = 0, 0
    while True:
        require(pos < len(data) and shift < 35, "invalid WASM unsigned LEB")
        byte = data[pos]
        pos += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, pos
        shift += 7


def string(data, pos):
    length, pos = uleb(data, pos)
    require(pos + length <= len(data), "WASM string overrun")
    return data[pos:pos + length].decode("utf-8"), pos + length


def needed(data):
    wasm(data)
    pos, found, result = 8, False, []
    while pos < len(data):
        section = data[pos]
        size, start = uleb(data, pos + 1)
        end = start + size
        require(end <= len(data), "WASM section overrun")
        if section == 0:
            name, at = string(data, start)
            if name == "dylink.0":
                require(not found, "duplicate dylink.0")
                found = True
                while at < end:
                    kind = data[at]
                    count, begin = uleb(data, at + 1)
                    stop = begin + count
                    require(stop <= end, "dylink subsection overrun")
                    if kind == 2:
                        n, cursor = uleb(data, begin)
                        for _ in range(n):
                            library, cursor = string(data, cursor)
                            result.append(library)
                        require(cursor == stop, "dylink needed length")
                    at = stop
        pos = end
    require(found, "missing side-module dylink.0")
    needed_libraries(result)
    return result


def result_audit(task):
    packet = Path(__file__).parent
    linkage = runpy.run_path(str(packet / "target_linkage.py"))
    link_graph = linkage["check_link_graph"]((task / "skbuild/build.ninja").read_text(), task)
    write(task / "dist-source/native-link-graph.json", link_graph)
    wrapper_path = task / "src/netgen/.pyodide_build/pywasmcross_symlinks/pywasmcross_env.json"
    wrapper = json.loads(wrapper_path.read_text())
    expected_wrapper = json.loads((packet / "wrapper-settings.json").read_text())
    require({key: wrapper.get(key) for key in expected_wrapper} == expected_wrapper,
            "effective Pyodide export/ABI/compiler flags changed")
    cache = {}
    for line in (task / "skbuild/CMakeCache.txt").read_text().splitlines():
        if line and not line.startswith(("#", "//")) and ":" in line and "=" in line:
            left, value = line.split("=", 1)
            cache[left.split(":", 1)[0]] = value
    expected = json.loads((task / "dist-source/input-pins.json").read_text())["cmakeDefinitions"]
    for name, value in expected.items():
        value = value.replace("@TASK@", str(task))
        require(cache.get(name) == value, "CMake effective setting mismatch: " + name)
    require("pywasmcross" in cache.get("CMAKE_CXX_COMPILER", ""), "host C++ compiler refused")
    wheels = list((task / "dist").glob("*.whl"))
    require(len(wheels) == 1, "expected exactly one wheel")
    wheel = wheels[0]
    require(wheel.name.endswith("-cp313-cp313-pyodide_2025_0_wasm32.whl"), "wrong wheel ABI")
    modules = {}
    with zipfile.ZipFile(wheel) as z:
        require(len(z.namelist()) == len(set(z.namelist())), "duplicate wheel member")
        for name in z.namelist():
            p = PurePosixPath(name)
            require(not p.is_absolute() and ".." not in p.parts and "\\" not in name,
                    "wheel path escape")
            if name.endswith(".so"):
                data = z.read(name)
                modules[name] = {"sha256": hashlib.sha256(data).hexdigest(),
                                 "bytes": len(data), "needed": needed(data)}
        require(set(modules) == {"libngcore.so", "libnglib.so", "netgen/libngpy.so",
                                "pyngcore/pyngcore.so"}, "unexpected native module set")
        config = z.read("netgen/config/config.py").decode()
        assignments = {node.targets[0].id: node.value for node in ast.parse(config).body
                       if isinstance(node, ast.Assign) and len(node.targets) == 1
                       and isinstance(node.targets[0], ast.Name)}
        source_version(ast.literal_eval(assignments["NETGEN_VERSION_GIT"]))
        for name in ("USE_OCC", "USE_MPI", "USE_GUI"):
            value = assignments[name]
            require(isinstance(value, ast.Call) and isinstance(value.func, ast.Name)
                    and value.func.id == "_cmake_to_bool" and len(value.args) == 1
                    and not value.keywords and ast.literal_eval(value.args[0]) == "OFF",
                    "wrong embedded build flag: " + name)
    provenance = {"wheel": wheel.name, "wheelSha256": sha(wheel), "modules": modules,
                  "effectiveCmake": cache, "runtimeImportExecuted": False,
                  "runtimeABIQualified": False, "legalClearance": False}
    write(task / "dist-source/build-provenance.json", provenance)
    print(json.dumps(provenance, indent=2))


def preserve(task, packet):
    inputs = json.loads((packet / "inputs.json").read_text())
    errors = []
    wrapper = {"path": inputs["pywasmcrossPath"], "sha256": inputs["pywasmcrossSha256"]}
    for row in inputs["files"] + inputs["environmentFiles"] + [wrapper]:
        try:
            pinned(row["path"], row["sha256"])
            if "resolved" in row:
                require(str(Path(row["path"]).resolve()) == row["resolved"], "resolved input changed")
        except Exception as error:
            errors.append(str(error))
    original_sources = task / "dist-source/source-before-build.json"
    if original_sources.exists():
        try:
            before = json.loads(original_sources.read_text())
            for name, digest in before.items():
                pinned(task / "src" / name, digest)
        except Exception as error:
            errors.append(str(error))
    prior_cache = task / "dist-source/prior-cache.json"
    if prior_cache.exists():
        try:
            require(tree_files(Path(inputs["emscriptenCache"])) == json.loads(prior_cache.read_text()),
                    "shared Emscripten cache changed")
        except Exception as error:
            errors.append(str(error))
    owned_cache = task / "cache/emscripten"
    if prior_cache.exists() and owned_cache.exists():
        try:
            before = json.loads(prior_cache.read_text())
            after = tree_files(owned_cache)
            write(task / "logs/owned-cache-delta.json", {
                "added": {k: v for k, v in after.items() if k not in before},
                "changed": {k: {"before": before[k], "after": v} for k, v in after.items()
                            if k in before and before[k] != v},
                "removed": [k for k in before if k not in after],
                "scope": "exclusive cloned cache with EM_FROZEN_CACHE=1; no runtime qualification",
            })
        except Exception as error:
            errors.append(str(error))
    write(task / "logs/preservation.json", {"errors": errors, "allPinnedInputsUnchanged": not errors})
    require(not errors, "input preservation failed")


def controls():
    rejected = []
    for name, action in (
        ("actual-dirty-source", lambda: source_version(VERSION + "-dirty")),
        ("old-unrelated-source", lambda: source_version("v6.2.2505")),
        ("unknown-library", lambda: needed_libraries(["libTKUnknown.so"])),
        ("host-object", lambda: wasm(b"\x7fELF" + bytes(28))),
    ):
        try:
            action()
        except ValueError:
            rejected.append(name)
        else:
            raise ValueError("refusal control did not reject: " + name)
    source_version(VERSION)
    needed_libraries(["libngcore.so", "libnglib.so"])
    wasm(b"\x00asm\x01\x00\x00\x00")
    print(json.dumps({"rejected": rejected, "validMetadataControls": 3,
                      "nativeExecuted": False}))


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "controls":
        controls()
    else:
        task, packet = Path(sys.argv[2]), Path(sys.argv[3])
        require(task.is_absolute() and task.resolve() == task, "owned task path must be real absolute")
        {"prepare": prepare, "objects": lambda t, p: object_audit(t),
         "result": lambda t, p: result_audit(t), "preserve": preserve}[mode](task, packet)
