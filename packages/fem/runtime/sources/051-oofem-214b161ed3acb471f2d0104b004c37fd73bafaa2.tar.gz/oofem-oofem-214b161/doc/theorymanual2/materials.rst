Material models documentation
#############################