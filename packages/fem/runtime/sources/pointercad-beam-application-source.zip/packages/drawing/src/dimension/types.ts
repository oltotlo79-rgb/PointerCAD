import type { DrawingElementStyle, DrawingExpressionValue, DrawingSubShapeRef, Point2, Vector3 } from '../types.js';

export type DimensionKind =
  | 'length'
  | 'diameter'
  | 'radius'
  | 'angle'
  | 'sphereDiameter'
  | 'sphereRadius'
  | 'arcLength'
  | 'thickness'
  | 'coordinate';

/** 寸法値をモデルからどう測るか。値そのものは保存しない(FR-706)。 */
export type DimensionMeasurement =
  | 'horizontal'
  | 'vertical'
  | 'trueDistance'
  | 'angle'
  | 'radius'
  | 'coordinate';

export type DimensionTarget =
  | {
      readonly kind: 'subShape';
      readonly viewId: string;
      readonly sourceRef: string;
      readonly componentId?: string;
      readonly ref: DrawingSubShapeRef;
    }
  | {
      readonly kind: 'point';
      readonly viewId: string;
      readonly paperPoint: Point2;
      readonly modelPoint?: Vector3;
    };

/** 手動配置でも数値は持たず、寸法線の紙上位置だけを保存する。 */
export interface DimensionPlacement {
  readonly commonNormalCoordinate: number;
  readonly textPosition: Point2 | null;
}

export type DimensionTolerance =
  | { readonly kind: 'symmetric'; readonly value: number | DrawingExpressionValue }
  | { readonly kind: 'deviation'; readonly upper: number | DrawingExpressionValue; readonly lower: number | DrawingExpressionValue };

/** 寸法の保存形。`value` は意図的に持たない(FR-706、FR-710)。 */
export interface Dimension {
  readonly id: string;
  readonly kind: DimensionKind;
  readonly measurement: DimensionMeasurement;
  readonly targets: readonly DimensionTarget[];
  readonly placement: DimensionPlacement;
  /** 累進寸法は1本の線と全参照を保存する。各目盛りの実値・描画形状は再計算する。 */
  readonly series?: { readonly kind: 'progressive'; readonly baseIndex: number };
  readonly tolerance?: DimensionTolerance;
  /** 許容差は公称寸法ごとに引き直す。表から導出する上下偏差は保存しない。 */
  readonly fit?: { readonly symbol: string; readonly showDeviation: boolean };
  readonly prefix?: string;
  readonly suffix?: string;
  readonly reference: boolean;
  /** 理論的に正確な寸法。公称値を長方形で囲み、寸法公差とは併用しない。 */
  readonly basic?: boolean;
  readonly origin: 'auto' | 'manual';
  readonly layerId: string;
  readonly style?: DrawingElementStyle | null;
}
