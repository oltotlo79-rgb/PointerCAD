;; This module is needed for two reasons:
;; 1. Clang/llvm is unable to generate the wasm GC instructions and types we need.
;; 2. wasm-gc has only been supported in Safari since December 2024 and since
;; NodeJS 22 in April 2024.
;;
;; In another year or so, reason 2 will go away. To address reason 1 my pipe dream
;; is to implement the needed primitives into llvm. But that will be a lot of work.
;;
;; Once it works in Safari, we can use wasm-merge to merge this module with the
;; main module which will allow better optimization.
(module
  (type $empty_struct (struct))

  (func (export "Jsv_GetError_import") (result externref)
    struct.new $empty_struct
    extern.convert_any
  )

  (func (export "JsvError_Check") (param $input externref) (result i32)
    local.get $input
    any.convert_extern
    ref.test (ref $empty_struct)
  )
)
