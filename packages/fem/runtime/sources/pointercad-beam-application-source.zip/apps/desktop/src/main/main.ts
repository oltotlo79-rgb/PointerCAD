import { app, BrowserWindow, ipcMain, Menu, session, shell } from 'electron';
import { isAllowedCamUrl } from '@pointercad/ui/open-with';
import { denyBrowserPermissions } from './sessionPermissions.js';
import type { IpcMainInvokeEvent } from 'electron';
import { join } from 'node:path';
import { readDrawingPrintOptions, type DrawingPrintOptions } from '@pointercad/ui/print-settings';
import { drawingPrintDocument } from './drawingPrintDocument.js';

import { APP_ENTRY_URL, handleAppScheme, registerAppScheme } from './appProtocol.js';
import { isAllowedAppUrl, registerAppWindow, validateAppSender } from './appSender.js';
import { registerCloseGuard } from './closeGuard.js';
import { PCAD_PRINT_CHANNEL, registerPcadIpc } from './pcadDialogs.js';
import { registerPortableCleanup } from './portableCleanup.js';
import { startupFailureDocument } from './startupHtml.js';
import { createOcctHttpTransport } from './occtHttpTransport.js';
import { launchOcctTransportEphemeralPort, OCCT_TRANSPORT_TEST_PORT_ENV } from '../occtHttpPolicy.js';

/**
 * このファイルの出力先 dist/main。
 * 計画書は `dirname(fileURLToPath(import.meta.url))` としていたが、Vite 8(Rolldown)は
 * CommonJS 出力で `import.meta` を空オブジェクトへ置き換えるため実行時に壊れる
 * (実測: `fileURLToPath({}.url)`)。出力形式は cjs で固定しているので `__dirname` を使う。
 */
// Pinned V8 debounce workaround; the existing byte threshold may serialize more frequently.
const existingJsFlags = app.commandLine.getSwitchValue('js-flags');
app.commandLine.appendSwitch('js-flags', [existingJsFlags, '--wasm-caching-timeout-ms=0'].filter(Boolean).join(' '));

const currentDirectory = __dirname;
/** dist/main から見た画面の出力先。 */
const rendererRoot = join(currentDirectory, '..', 'renderer');
const preloadPath = join(currentDirectory, '..', 'preload', 'preload.cjs');

/** 開発時は Vite の開発サーバーを読む。統括が起動して環境変数で渡す。 */
const devServerUrl = app.isPackaged ? undefined : process.env['PCAD_DEV_SERVER_URL'];
/** 製品は固定の送信先。未パッケージの画面検査だけ、OCCT の HTTP サーバー自身が OS の選ぶ番号を bind して持ち続ける。 */
const occtTransportEphemeralPort = launchOcctTransportEphemeralPort(app.isPackaged, process.env[OCCT_TRANSPORT_TEST_PORT_ENV]);

registerAppScheme();
// The single-file portable removes this launch's %TEMP% extraction after a confirmed quit (v1.0.2). The helper and its
// starter are staged script files run with -File; noEncodedPowerShell.test.ts keeps encoded or inline launches out.
registerPortableCleanup(app);

function createMainWindow(): void {
  const started = performance.now();
  const stage = (name: string): void => {
    console.info(`[pcad:desktop-startup] ${JSON.stringify({ stage: name,
      elapsedMs: Math.round((performance.now() - started) * 100) / 100,
      processMs: Math.round(performance.now() * 100) / 100, timeOrigin: performance.timeOrigin })}`);
  };
  const window = new BrowserWindow({
    width: 1440,
    height: 900,
    // これより狭いとツールバーの機能グループが折り返して読みにくくなる。
    minWidth: 960,
    minHeight: 600,
    // Show the dark window immediately; app:// supplies a tiny static splash before editor JS.
    show: true,
    autoHideMenuBar: true,
    // 画面本体の地の色(appShell.css の --pcad-bg)と合わせる。
    backgroundColor: '#16181d',
    title: 'PointerCAD',
    webPreferences: {
      preload: preloadPath,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      webviewTag: false,
    },
  });
  stage('window-created');
  registerAppWindow(window);

  window.webContents.on('will-navigate', (event, targetUrl) => {
    if (!isAllowedAppUrl(targetUrl, devServerUrl)) {
      event.preventDefault();
    }
  });
  window.webContents.on('will-redirect', (event) => {
    if (!isAllowedAppUrl(event.url, devServerUrl)) event.preventDefault();
  });
  window.webContents.on('will-attach-webview', (event) => { event.preventDefault(); });
  // 加工先は検証済みの専用IPCから固定HTTPSだけを開く。一般の新窓要求は許可しない。
  window.webContents.setWindowOpenHandler(({ url }) => {
    // ヘルプ内の公式リンクも完全一致の表だけをOSへ渡す。アプリ内の新窓は作らない。
    if (isAllowedCamUrl(url)) void shell.openExternal(url).catch(() => undefined);
    return { action: 'deny' };
  });

  window.webContents.on('dom-ready', () => { stage('document-ready'); });
  window.webContents.on('did-finish-load', () => { stage('document-loaded'); });

  stage('navigation-start');
  void window.loadURL(devServerUrl ?? APP_ENTRY_URL).catch(error => {
    if (window.isDestroyed()) return;
    stage('document-failed');
    console.error('PointerCAD document load failed', error);
    const fallback = startupFailureDocument(devServerUrl ?? APP_ENTRY_URL);
    void window.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(fallback)}`)
      .catch(recoveryError => { console.error('PointerCAD recovery document failed', recoveryError); });
  });
}

/**
 * 印刷(FR-810。P6 計画書 §2.11、タスク29)。
 *
 * 画面から PNG のバイト列を受け取り、**隠しの窓**へ data URL として読み込ませてから
 * `webContents.print()` を呼ぶ。画面の窓をそのまま印刷しないのは、ツールバーや区画まで
 * 紙に出てしまうため。紙に出すのは、画面側が背景を白にして描いた 1 コマだけ(FR-908)。
 *
 * 部品の画像はOSの印刷設定を使う。図面は検証済みの用紙・向き・部数を初期値にする。
 * どちらも `silent: false` で、利用者が印刷画面で確認できる。
 * 取り消しは `success` が false で返る。**例外にしない**(NFR-RE-1)。
 *
 * **隠しの窓は `finally` で必ず閉じる。** 閉じ忘れると見えない窓が残り、
 * 画面の窓を全部閉じてもアプリが終わらなくなる。
 */
async function printInHiddenWindow(png: Uint8Array, options?: DrawingPrintOptions): Promise<boolean> {
  const printWindow = new BrowserWindow({
    title: 'PointerCAD',
    show: false,
    webPreferences: {
      // 絵を 1 枚出すだけなので、画面の口(preload)は渡さない。
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      webviewTag: false,
    },
  });
  printWindow.webContents.on('will-navigate', (event, targetUrl) => {
    if (!isAllowedAppUrl(targetUrl, devServerUrl)) {
      event.preventDefault();
    }
  });
  printWindow.webContents.on('will-redirect', (event) => {
    if (!isAllowedAppUrl(event.url, devServerUrl)) event.preventDefault();
  });
  printWindow.webContents.on('will-attach-webview', (event) => { event.preventDefault(); });
  // P11b タスク 1 の固定 HTTPS 許可表による外部リンク処理は、この拒否口へ追加する。
  printWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  try {
    const dataUrl = options === undefined ? `data:image/png;base64,${Buffer.from(png).toString('base64')}`
      : `data:text/html;base64,${Buffer.from(drawingPrintDocument(png, options)).toString('base64')}`;
    await printWindow.loadURL(dataUrl);
    await printWindow.webContents.executeJavaScript('Promise.all(Array.from(document.images, image => image.decode()))');
    return await new Promise<boolean>((resolve) => {
      printWindow.webContents.print({ silent: false, printBackground: true, ...(options === undefined ? {}
        : { pageSize: options.pageSize, landscape: options.landscape, copies: options.copies, margins: { marginType: 'none' }, scaleFactor: 100 }) }, (success) => {
        resolve(success);
      });
    });
  } finally {
    printWindow.destroy();
  }
}

/**
 * 印刷の受け口を登録する。`app.whenReady()` の中から1回だけ呼ぶ
 * (`registerPcadIpc` と同じ理由。2回呼ぶと Electron が二重登録で失敗する)。
 */
function registerPrintIpc(): void {
  ipcMain.handle(
    PCAD_PRINT_CHANNEL,
    async (event: IpcMainInvokeEvent, ...args: unknown[]): Promise<boolean> => {
      if (!validateAppSender(event)) {
        return false;
      }
      const [png, rawOptions] = args;
      if (!(png instanceof Uint8Array)) {
        throw new Error('印刷の依頼の形が正しくありません。');
      }
      const options = rawOptions === undefined ? undefined : readDrawingPrintOptions(rawOptions);
      if (options === null) throw new Error('図面の印刷設定が正しくありません。');
      return printInHiddenWindow(png, options);
    },
  );
}

/**
 * 画面検査の起動だけ: 主文書の前に準備して、サーバーが実際に持っている origin を CSP へ 1 回渡す。
 * 準備の失敗・direct は固定の origin のまま進め、renderer の準備の要求が同じ結果で明示的に失敗する。
 */
async function ownedOcctTransportOrigin(transport: ReturnType<typeof createOcctHttpTransport>): Promise<string | undefined> {
  try {
    const reply = await transport.prepare();
    return reply.kind === 'http' ? new URL(reply.url).origin : undefined;
  } catch (error: unknown) {
    console.error('OCCT transport preparation failed', error);
    return undefined;
  }
}

void app.whenReady().then(async () => {
  denyBrowserPermissions(session.defaultSession);
  session.defaultSession.on('will-download', (event) => { event.preventDefault(); });
  // 既定のメニューバー(File / Edit / View / Window)は使わないので消す。
  Menu.setApplicationMenu(null);
  // Construction only (no listener, read or network); the product keeps the lazy order below.
  const occtTransport = createOcctHttpTransport(rendererRoot, session.defaultSession, occtTransportEphemeralPort);
  handleAppScheme(rendererRoot, occtTransportEphemeralPort ? await ownedOcctTransportOrigin(occtTransport) : undefined);
  // Register lazily: the first broker acquisition owns preparation and its timing.
  ipcMain.handle('pcad:prepareOcctTransport', (event: IpcMainInvokeEvent, ...args: unknown[]) => {
    if (!validateAppSender(event) || args.length !== 0) throw new Error('Invalid OCCT transport sender or arguments');
    return occtTransport.prepare();
  });
  app.once('before-quit', () => {
    void occtTransport.close().catch(error => { console.error('OCCT transport close failed', error); });
  });
  // 「開く」「保存」の受け口。窓を作る前に用意しておく(FR-806、計画書 タスク26)。
  registerPcadIpc();
  // 「印刷」の受け口(FR-810、P6 計画書 タスク29)。
  registerPrintIpc();
  // 窓を閉じるときの未保存の確認(レビュー R03)。窓を作る前に見張りを付ける。
  registerCloseGuard();
  createMainWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
