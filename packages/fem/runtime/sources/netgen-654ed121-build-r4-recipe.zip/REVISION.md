Root-only build-r4: correct source-byte admission; r1/r2/r3 failures and tasks remain immutable. No worker execution.

Actual cause: I promoted the r2 text observation hash2b5cec53 to an upstream source-byte pin without checking the original archive member. The preserved archive member and r3 extracted ng/netgenpy.cpp are identical1075 bytes, SHA cf4f7134c3d629094cea248b72e5fd87595a8af0bbc5120b674874afa9f13beb, with30 CRLF. Replacing only CRLF with LF produces exactly1045 bytes/SHA2b5cec5331e70788d8aa4b236550d3df1c7116a540438fd060acfee8e82d1606 and byte-equals the r2 observation. This is text-capture normalization, not evidence of a compiler/source-stage mutation. Normalization is used only to explain the failure, never to admit source.

Root actual r3 receipt fb772ce7beb2dbeaadc05d5255962f531ba104ae2c8c67cb1e6c1c52c6caa7b2 records primary1, preservation0 and owned reap. Six link/source controls passed0.022s and ten supervisor controls passed0.049s, but they did not compare the shim pin to archive bytes; hence they could not prevent this admission failure. No compiler was reached.

Minimal correction: change only that one nativeLinkSourcePins value to the raw archive SHA. Keep the CMake ownership patch, compiler/exception/export flags, all old assets and licenses, native quality/oracles, deadline900s and cleanup unchanged. ng/CMakeLists.txt and nglib/CMakeLists.txt raw pins already match their exact archive members.

Physical prevention: native_link_archive_members reads exactly the three admitted regular members directly from the SHA-pinned Netgen archive, verifies complete expected member coverage and unconverted source hashes before extraction/compiler, and records bytes/CRLF/LF counts. Existing extracted-file checks remain. Three new Root-only control methods prove current raw pins, reject the actual old normalized shim pin, and reject wrong/omitted pins across all three source files. Both raw and normalized shim fixtures remain immutable and explicitly distinct. No relaxed hash comparison or line-ending rewriting.

Root first runs root-command.json sourceByteControlsArgv (three methods; reads archive only), then the existing fresh owned supervisor. The build itself repeats the same admission controls before compiler, retains six graph controls, and verifies actual generated linkage/unchanged wrapper settings on success. Source/QA/dependency/index checks remain Root-owned. This candidate is authored only; runtime import, fixed PLC proof, curved analysis mesh and distribution/legal qualification remain open.

Source closure is unchanged upstream commit654ed121e44cedc4db45f955d9ab6ddf8dd48806 plus the explicit r3 Emscripten-only CMake patch. The original REPORT.md describes build-r1 closure; r3/REVISION.md preserves link diagnosis and r4/REVISION.md supersedes source-pin admission only. New task /home/yuya/pcad-netgen-clean-20261012-build-r4 must not preexist.

子エージェントの使用: なし
 git への書き込み: なし
